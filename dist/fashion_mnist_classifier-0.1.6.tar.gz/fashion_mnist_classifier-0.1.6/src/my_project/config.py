"""
Configuration constants for the Fashion-MNIST project.

This file can be used for global constants that are shared across different
modules of the project.
"""
