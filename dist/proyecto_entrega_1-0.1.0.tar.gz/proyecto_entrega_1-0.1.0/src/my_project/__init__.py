"""
My Project: Fashion-MNIST Image Classification

.. include:: ../../README.md
"""