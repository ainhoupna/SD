from my_project.config import TRAIN_CSV_PATH, TEST_CSV_PATH, NUM_WORKERS

EXP_PARAMS = {
    "batch_size": 64,
    "lr": 0.001,
    "epochs": 10
}
